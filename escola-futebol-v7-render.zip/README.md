# Sistema de Cadastro - Escola de Futebol

## Como rodar o projeto:
1. Criar ambiente virtual e instalar dependências:
```
pip install -r requirements.txt
```

2. Configurar variáveis de ambiente e banco PostgreSQL:
- Criar banco `escola_futebol`
- Editar `config.py` com usuário/senha corretos

3. Rodar o sistema:
```
Linux: sh run.sh
Windows: run.bat
```
