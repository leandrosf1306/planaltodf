from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from io import BytesIO
from models.models import Aluno, Pagamento

def gerar_pdf():
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=A4)
    c.setFont("Helvetica", 12)
    c.drawString(50, 800, "Relatório Financeiro - Escola de Futebol")
    y = 750
    pagamentos = Pagamento.query.all()
    for p in pagamentos:
        texto = f"Aluno ID: {p.aluno_id} | Mês: {p.mes} | Valor: R$ {p.valor} | Status: {p.status}"
        c.drawString(50, y, texto)
        y -= 20
    c.showPage()
    c.save()
    buffer.seek(0)
    return buffer
