from flask import Blueprint, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
import os, uuid
from models.models import db, Aluno, Responsavel

UPLOAD_FOLDER = 'static/img/alunos'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

public_bp = Blueprint('public', __name__)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@public_bp.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome = request.form['nome']
        data_nascimento = request.form['data_nascimento']
        categoria = request.form['categoria']
        telefone = request.form['telefone']
        endereco = request.form['endereco']

        foto_file = request.files['foto']
        foto_filename = None
        if foto_file and allowed_file(foto_file.filename):
            ext = foto_file.filename.rsplit('.', 1)[1].lower()
            foto_filename = f"{uuid.uuid4()}.{ext}"
            foto_path = os.path.join(UPLOAD_FOLDER, foto_filename)
            foto_file.save(foto_path)

        aluno = Aluno(nome=nome, data_nascimento=data_nascimento, categoria=categoria, telefone=telefone, endereco=endereco, foto=foto_filename)

        # Responsáveis
        resp1_nome = request.form.get('resp1_nome')
        resp1_telefone = request.form.get('resp1_telefone')
        resp1_email = request.form.get('resp1_email')

        resp2_nome = request.form.get('resp2_nome')
        resp2_telefone = request.form.get('resp2_telefone')
        resp2_email = request.form.get('resp2_email')

        if resp1_nome:
            r1 = Responsavel(nome=resp1_nome, telefone=resp1_telefone, email=resp1_email)
            aluno.responsaveis.append(r1)
            db.session.add(r1)
        if resp2_nome:
            r2 = Responsavel(nome=resp2_nome, telefone=resp2_telefone, email=resp2_email)
            aluno.responsaveis.append(r2)
            db.session.add(r2)

        db.session.add(aluno)
        db.session.commit()
        return redirect(url_for('public.cadastro'))
    return render_template('cadastro_publico.html')
