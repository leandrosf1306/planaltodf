from flask import Blueprint, render_template, request, redirect, url_for, send_file
from models.models import db, Pagamento, Aluno
import io
from reports.pdf_generator import gerar_pdf
from reports.excel_generator import gerar_excel

financeiro_bp = Blueprint('financeiro', __name__)

@financeiro_bp.route('/financeiro', methods=['GET', 'POST'])
def financeiro():
    if request.method == 'POST':
        aluno_id = request.form['aluno_id']
        mes = request.form['mes']
        valor = request.form['valor']
        status = request.form['status']
        pagamento = Pagamento(aluno_id=aluno_id, mes=mes, valor=valor, status=status)
        db.session.add(pagamento)
        db.session.commit()
        return redirect(url_for('financeiro.financeiro'))
    
    pagamentos = Pagamento.query.all()
    alunos = Aluno.query.all()
    return render_template('financeiro.html', pagamentos=pagamentos, alunos=alunos)

@financeiro_bp.route('/relatorios/pdf')
def relatorio_pdf():
    buffer = gerar_pdf()
    return send_file(buffer, as_attachment=True, download_name="relatorio.pdf", mimetype='application/pdf')

@financeiro_bp.route('/relatorios/excel')
def relatorio_excel():
    buffer = gerar_excel()
    return send_file(buffer, as_attachment=True, download_name="relatorio.xlsx", mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
