from flask import Flask
from routes.public import public_bp
from routes.auth import auth_bp
from routes.admin import admin_bp
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

app = Flask(__name__)
app.config.from_object('config.Config')

db = SQLAlchemy(app)
login_manager = LoginManager(app)

# Blueprints
app.register_blueprint(public_bp)
app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp)

if __name__ == "__main__":
    app.run(debug=True)

from routes.financeiro import financeiro_bp
app.register_blueprint(financeiro_bp)

from models.models import Usuario
from flask_login import LoginManager

login_manager = LoginManager(app)
login_manager.login_view = 'auth.login'

@login_manager.user_loader
def load_user(user_id):
    return Usuario.query.get(int(user_id))

from flask_mail import Mail
mail = Mail(app)

from routes.alunos import alunos_bp
app.register_blueprint(alunos_bp)
