from flask_mail import Message
from app import mail

def enviar_email_responsaveis(aluno):
    for responsavel in aluno.responsaveis:
        msg = Message('Confirmação de Cadastro', sender='seu_email@gmail.com', recipients=[responsavel.email])
        msg.body = f"Olá {responsavel.nome},\n\nO aluno {aluno.nome} foi cadastrado na categoria {aluno.categoria}.\n\nEscola de Futebol"
        mail.send(msg)
