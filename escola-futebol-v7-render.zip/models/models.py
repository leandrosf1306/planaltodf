from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Usuario(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True)
    senha = db.Column(db.String(255))
    perfil = db.Column(db.String(50))

class Responsavel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100))
    cpf = db.Column(db.String(14))
    telefone = db.Column(db.String(15))
    email = db.Column(db.String(100))

class Aluno(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100))
    data_nascimento = db.Column(db.Date)
    cpf = db.Column(db.String(14))
    endereco = db.Column(db.Text)
    telefone = db.Column(db.String(15))
    categoria = db.Column(db.String(20))
    foto = db.Column(db.String(255))
    responsavel_id = db.Column(db.Integer, db.ForeignKey('responsavel.id'))

class Pagamento(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    aluno_id = db.Column(db.Integer, db.ForeignKey('aluno.id'))
    mes = db.Column(db.String(20))
    valor = db.Column(db.Numeric(10,2))
    status = db.Column(db.String(20))


from functools import wraps
from flask import redirect, url_for
from flask_login import current_user

def role_required(roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if current_user.perfil not in roles:
                return redirect(url_for('auth.login'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

from flask_login import UserMixin

class Usuario(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100))
    email = db.Column(db.String(100), unique=True)
    senha = db.Column(db.String(255))
    perfil = db.Column(db.String(50))

    def get_id(self):
        return str(self.id)

from sqlalchemy.orm import relationship

aluno_responsavel = db.Table('aluno_responsavel',
    db.Column('aluno_id', db.Integer, db.ForeignKey('aluno.id')),
    db.Column('responsavel_id', db.Integer, db.ForeignKey('responsavel.id'))
)

class Aluno(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100))
    data_nascimento = db.Column(db.Date)
    cpf = db.Column(db.String(14))
    endereco = db.Column(db.Text)
    telefone = db.Column(db.String(15))
    categoria = db.Column(db.String(20))
    foto = db.Column(db.String(255))
    responsaveis = db.relationship('Responsavel', secondary=aluno_responsavel, backref='alunos')
