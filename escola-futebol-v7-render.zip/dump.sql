CREATE TABLE usuarios (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    senha VARCHAR(255),
    perfil VARCHAR(50)
);

CREATE TABLE responsaveis (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    cpf VARCHAR(14),
    telefone VARCHAR(15),
    email VARCHAR(100)
);

CREATE TABLE alunos (
    id SERIAL PRIMARY KEY,
    nome VARCHAR(100),
    data_nascimento DATE,
    cpf VARCHAR(14),
    endereco TEXT,
    telefone VARCHAR(15),
    categoria VARCHAR(20),
    foto VARCHAR(255),
    responsavel_id INT REFERENCES responsaveis(id)
);

CREATE TABLE pagamentos (
    id SERIAL PRIMARY KEY,
    aluno_id INT REFERENCES alunos(id),
    mes VARCHAR(20),
    valor DECIMAL(10,2),
    status VARCHAR(20)
);
