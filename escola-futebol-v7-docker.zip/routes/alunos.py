from flask import Blueprint, render_template, request, redirect, url_for
from models.models import db, Aluno, Responsavel
from utils.email_service import enviar_email_responsaveis

alunos_bp = Blueprint('alunos', __name__)

@alunos_bp.route('/alunos')
def listar_alunos():
    alunos = Aluno.query.all()
    return render_template('alunos.html', alunos=alunos)

@alunos_bp.route('/aluno/<int:id>/editar', methods=['GET', 'POST'])
def editar_aluno(id):
    aluno = Aluno.query.get_or_404(id)
    if request.method == 'POST':
        aluno.nome = request.form['nome']
        aluno.categoria = request.form['categoria']
        aluno.telefone = request.form['telefone']
        aluno.endereco = request.form['endereco']
        db.session.commit()
        return redirect(url_for('alunos.listar_alunos'))
    return render_template('editar_aluno.html', aluno=aluno)

@alunos_bp.route('/aluno/<int:id>/excluir', methods=['POST'])
def excluir_aluno(id):
    aluno = Aluno.query.get_or_404(id)
    db.session.delete(aluno)
    db.session.commit()
    return redirect(url_for('alunos.listar_alunos'))
