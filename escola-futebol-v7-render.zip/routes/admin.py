
from flask import Blueprint, render_template, jsonify
from models.models import Aluno, Pagamento
from sqlalchemy import func
from datetime import datetime, timedelta

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard')
def dashboard():
    alunos = Aluno.query.order_by(Aluno.id.desc()).limit(6).all()
    return render_template('dashboard.html', alunos=alunos)

@admin_bp.route('/api/dashboard-data')
def dashboard_data():
    categorias = {}
    for aluno in Aluno.query.all():
        categorias[aluno.categoria] = categorias.get(aluno.categoria, 0) + 1

    pagos = Pagamento.query.filter_by(status='Pago').count()
    pendentes = Pagamento.query.filter_by(status='Pendente').count()

    total_pago = db.session.query(func.sum(Pagamento.valor)).filter_by(status='Pago').scalar() or 0
    total_pendente = db.session.query(func.sum(Pagamento.valor)).filter_by(status='Pendente').scalar() or 0

    # Tendência últimos 6 meses
    hoje = datetime.today()
    meses = []
    receitas = []
    for i in range(5, -1, -1):
        inicio = (hoje.replace(day=1) - timedelta(days=30*i)).replace(day=1)
        fim = (inicio + timedelta(days=30))
        soma_mes = db.session.query(func.sum(Pagamento.valor)).filter(
            Pagamento.status=='Pago',
            Pagamento.id != None
        ).scalar() or 0
        meses.append(inicio.strftime('%b'))
        receitas.append(float(soma_mes))

    return jsonify({
        'categorias': categorias,
        'financeiro': {'Pagos': pagos, 'Pendentes': pendentes},
        'kpis': {
            'total_pago': float(total_pago),
            'total_pendente': float(total_pendente)
        },
        'tendencia': {'meses': meses, 'receitas': receitas}
    })
