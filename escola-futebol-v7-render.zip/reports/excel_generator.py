import pandas as pd
from io import BytesIO
from models.models import Pagamento

def gerar_excel():
    pagamentos = Pagamento.query.all()
    data = [{"Aluno ID": p.aluno_id, "Mês": p.mes, "Valor": float(p.valor), "Status": p.status} for p in pagamentos]
    df = pd.DataFrame(data)
    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Financeiro')
    output.seek(0)
    return output
