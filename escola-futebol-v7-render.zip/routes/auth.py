from flask import Blueprint, render_template, request, redirect, url_for
from flask_login import login_user, logout_user, login_required
from models.models import db, Usuario
from werkzeug.security import generate_password_hash, check_password_hash

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']
        user = Usuario.query.filter_by(email=email).first()
        if user and check_password_hash(user.senha, senha):
            login_user(user)
            return redirect(url_for('admin.dashboard'))
        else:
            return render_template('login.html', erro='Credenciais inválidas')
    return render_template('login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))

@auth_bp.route('/usuarios', methods=['GET', 'POST'])
@login_required
def usuarios():
    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        senha = generate_password_hash(request.form['senha'])
        perfil = request.form['perfil']
        novo_usuario = Usuario(nome=nome, email=email, senha=senha, perfil=perfil)
        db.session.add(novo_usuario)
        db.session.commit()
        return redirect(url_for('auth.usuarios'))
    usuarios = Usuario.query.all()
    return render_template('usuarios.html', usuarios=usuarios)
